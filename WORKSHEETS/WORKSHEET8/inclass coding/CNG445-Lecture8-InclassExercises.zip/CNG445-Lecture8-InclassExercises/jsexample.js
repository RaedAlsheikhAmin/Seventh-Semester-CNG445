	function fun1(){
		document.getElementById('p1').innerHTML='How are you?';
	}
	
	function fun2(){
		document.getElementById('p1').style.fontSize='70px';
	}
	
	function fun3(){
		document.getElementById('p1').style.display='none';
	}
	
	function fun4(){
		document.getElementById('p2').style.display='block';
	}
	
	function fun5(){
		window.alert('I am here!');
	}