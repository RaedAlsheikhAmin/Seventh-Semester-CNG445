from flask import *
import sqlite3

app = Flask(__name__)
app.secret_key = "123"
if __name__ == "__main__":
    pass