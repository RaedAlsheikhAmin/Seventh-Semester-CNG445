from Point import *

p1 = Point()
p2 = Point(2,3)
print(p1)
print(p2)

#p2.z = 10

print(p2.x)