from flask import *

app= Flask(__name__)

@app.route("/")
def index():
    return render_template("index.html")

@app.get("/gethint")
def gethint():
    names=["Anna","Raed", "Farnaz", "Hamoode", "muhammed","hey", "hasona","heosssa"]

    suggestions= []
    keyword = request.args.get("q",None) #if available i will get its value, otehrwise it willr return non
    if(keyword !=None):
        for name in names:
            if keyword.lower() == name[0:len(keyword)].lower():#important to understand, we can use (in) instead of equality if we want to check if it is in the word itself
                suggestions.append(name)
    return ", ".join(suggestions)
if __name__=="__main__":
    app.run()
