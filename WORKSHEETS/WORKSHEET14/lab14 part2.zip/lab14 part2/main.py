from flask import *
app= Flask(__name__)

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/getxml")
def getxml():
    xmlDoc = open("data/bookstore.xml").read()#to read the content all together
    return Response(xmlDoc, mimetype="text/xml")#i want to return it in xml format, mimetype="text/xml" means it is xml typle.
if __name__=="__main__":
    app.run()