Team members: Raed Alsheikh Amin 2528271- Farnaz Rezaei Noey 2551406
o version of Python 3.9.12 
o operating system Windows 11
o We worked on all the parts together to acheive the final result, Raed tested the program to make sure that it is functioning according to the requriments.