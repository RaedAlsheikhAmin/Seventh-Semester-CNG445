Team Members
    Name: Muhammad A Guluzade
    ID: 2545952
    Name: Turgut Canberk Diner
    ID : 2453157

Python Version
    Python 3.11

Operating System
    Windows 11

The Division of Tasks
    The STEPs are described in the comment section of "commitsanalyser.py" file

    STEP_1 - STEP_5 (Reading the files and storing the data in the proper format)
        Turgut Canberk Diner

    STEP_6 (The main loop and all corresponding code regarding the charts and user choices)
        Muhammad A Guluzade

    Comments from Muhammad A Guluzade
        My responsibility was to create a loop that the user is going to see
        and make his/her choices. I have implemented all algorithms related to
        that loop and ensured that the program does not crash if the user inputs
        any type of the value that may throw an exception. I have also wrote the code
        for the matplotlib bar charts and styled them to make them more readable.

    Comments from Turgut Canberk Diner
        <------ WRITE YOUR COMMENTS HERE BRO ------>

    Work done together
        There was also a part of the work that was not clearly divided between us.
        It was testing the code and ensuring that the outputs and charts are correct.
        For the sake of testing, we have met in person and checked every condition in
        the program, and fixed some parts of the code where it was giving incorrect
        outputs.