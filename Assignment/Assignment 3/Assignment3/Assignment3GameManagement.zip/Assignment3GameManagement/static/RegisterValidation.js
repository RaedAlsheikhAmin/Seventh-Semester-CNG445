function registerValidation(str) {
    ;
    if (str.length === 0) {
        document.getElementById("errormessageusername").innerHTML = "please fill the username";
        return;
    } else {
        var xmlhttp = new XMLHttpRequest();
        xmlhttp.onreadystatechange = function () {
            if (this.readyState === 4 && this.status === 200) {
                document.getElementById("errormessageusername").innerHTML = this.responseText;
            }
        }
        xmlhttp.open("POST", "/Validateusername?q=" + str, true);
        xmlhttp.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
        xmlhttp.send();
    }
}