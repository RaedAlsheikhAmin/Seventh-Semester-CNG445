from flask import *
import sqlite3

app = Flask(__name__)
app.secret_key = '123'
def check_username_in_db(username):
    conn = sqlite3.connect("GameWebsite.db")
    cursor = conn.cursor()
    cursor.execute("SELECT username FROM User WHERE username = ?", (username,))
    result = cursor.fetchone()
    conn.close()
    return result is not None

@app.route("/")
def index():
    return render_template("/index.html")

@app.route("/login", methods=["POST"])
def login():
    #To get the values using post method
    username = request.form["username"]
    password = request.form["password"]

    # Connect to the database
    conn = sqlite3.connect("GameWebsite.db")
    c = conn.cursor()

    # Verify user credentials
    c.execute("SELECT username, isAdmin FROM User WHERE username = ? AND password = ?", (username, password))
    row = c.fetchone()
    conn.close()


    if row: #that means the use if found in the query
        session["username"] = row[0]
        session["isAdmin"] = row[1] == 1
        return redirect(url_for("dashboard"))
    else:
        return render_template("login.html")

@app.route("/logout")
def logout():
    session.pop("username","")
    return redirect(url_for("index"))
@app.route("/Validateusername", methods=["POST"])
def check_username():
    username = request.args.get("q", "") #get variable q, if nothing then empty
    if not username:
        return ""
    if check_username_in_db(username):
        return "Username is already taken."
    else:
        return "Username is available."

if __name__=='__main__':
    app.run()