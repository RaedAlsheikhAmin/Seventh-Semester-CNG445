Team Members
    Name: Muhammad A Guluzade
    ID: 2545952
    Name: Turgut Canberk Diner
    ID : 2453157

Python Version
    Python 3.11

Operating System
    Windows 11

The Division of Tasks

    We communicated in person and via Discord in order to test and demonstrate what
    we did so far regarding our parts.

    Muhammad Amin Guluzade worked on dbscript.py, and register/login/logout part
    of the main.py and html files. In addition, he worked on CSS styling of the 
    entire website and JavaScipt form validation.

    Turgut Canberk Diner worked on advertisements, profile, and details parts of
    main.py and corresponding html files. 