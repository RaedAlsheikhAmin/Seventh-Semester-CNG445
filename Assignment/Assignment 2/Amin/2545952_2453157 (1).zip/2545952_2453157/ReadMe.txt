Team Members
    Name: Muhammad A Guluzade
    ID: 2545952
    Name: Turgut Canberk Diner
    ID : 2453157

Python Version
    Python 3.11

Operating System
    Windows 11

The Division of Tasks

    Methods of communication
        There were several meetings in the library and several Discord meetings where we shared the
        progress and discussed what to do next.
    Testing the program
        Each team member tested his own part of the code on his own computer to ensure the correct
        functionality before sharing with the other partner
    client.py
        Main division of tasks was as follows:

        Manager function - Turgut Canberk Diner
        Librarian function - Muhammad A Guluzade

        Turgut Canberk Diner developed GUI and functionality of manager part
        Muhammad A Guluzade developed GUI and functionality of librarian part

        Login part - GUI was implemented by Turgut Canberk Diner, and functionality
        was implemented by Muhammad A Guluzade

    server.py :
        similar to client.py division of tasks, Turgut Canberk Diner implemented manager
        response from the server, and Muhammad A Guluzade implemented librarian response
        from the server.